# Offline School Learning Management System

Desktop app to manage student info, grades, attendance, and more.