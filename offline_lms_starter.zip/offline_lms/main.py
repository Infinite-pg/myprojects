# Entry point for the Offline LMS app

if __name__ == '__main__':
    print('Offline LMS launched.')