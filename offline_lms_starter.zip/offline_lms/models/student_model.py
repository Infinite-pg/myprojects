# Model for student operations

def add_student(conn, student):
    pass  # implement